// Maps a nav item's data-view to the page it should link to.
// Add an entry here once a new screen actually exists.
const NAV_ROUTES = {
  draft: 'draft-review.html',
  signoff: 'sign-off.html',
  filed: 'note-filed.html',
};

// Reads <body data-page="..."> to know which screen is currently showing,
// then marks the matching nav item active, makes built screens clickable,
// and leaves not-yet-built screens visibly disabled. One nav definition
// in the HTML, no per-page "active"/"disabled" duplication needed.
function initNav() {
  const currentPage = document.body.dataset.page;

  document.querySelectorAll('.navitem').forEach((item) => {
    const view = item.dataset.view;

    if (view === currentPage) {
      item.classList.add('active');
      item.setAttribute('aria-current', 'step');
      return;
    }

    const href = NAV_ROUTES[view];

    if (!href) {
      item.classList.add('disabled');
      item.setAttribute('aria-disabled', 'true');
      return;
    }

    item.classList.add('navlink');
    item.setAttribute('role', 'link');
    item.setAttribute('tabindex', '0');

    const go = () => {
      window.location.href = href;
    };

    item.addEventListener('click', go);
    item.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        go();
      }
    });
  });
}

// Buttons for screens that don't exist yet (e.g. "Modify draft" before
// Draft Review is built). Clicking gives honest feedback instead of doing
// nothing silently.
function initPlaceholderButtons() {
  document.querySelectorAll('[data-placeholder]').forEach((button) => {
    const originalText = button.textContent;

    button.addEventListener('click', () => {
      button.textContent = button.dataset.placeholder;
      button.disabled = true;

      setTimeout(() => {
        button.textContent = originalText;
        button.disabled = false;
      }, 2000);
    });
  });
}

// Draft Review: tap a note line to reveal the transcript snippet it came
// from. Each .noteitem toggles its own data-expanded attribute, which the
// CSS reads to show/hide the .transcript panel.
function initNoteLines() {
  document.querySelectorAll('.noteitem').forEach((item) => {
    const head = item.querySelector('.head');
    if (!head) return;

    const setExpanded = (expanded) => {
      item.setAttribute('data-expanded', expanded ? 'true' : 'false');
      head.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    };

    head.addEventListener('click', () => {
      const isExpanded = item.getAttribute('data-expanded') === 'true';
      setExpanded(!isExpanded);
    });
  });
}

// Quick clinical action buttons that are simple on/off toggles
// (e.g. "Flag urgent") rather than placeholders or navigation.
function initToggleButtons() {
  document.querySelectorAll('[data-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      button.classList.toggle('toggled');
      const isOn = button.classList.contains('toggled');
      button.setAttribute('aria-pressed', isOn ? 'true' : 'false');
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initPlaceholderButtons();
  initNoteLines();
  initToggleButtons();
});
