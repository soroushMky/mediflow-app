import { useState } from 'react';
import SignOff from './SignOff';
import NoteFiled from './NoteFiled';
import DraftReview from './DraftReview';

// As more screens get built, add them here and to BUILT_VIEWS in SignOff.jsx.
const SCREENS = {
  draft: DraftReview,
  signoff: SignOff,
  filed: NoteFiled,
};

export default function App() {
  const [view, setView] = useState('signoff');
  const Screen = SCREENS[view];

  return <Screen onNavigate={setView} />;
}
